function [ imgOut ] = overImgResults( imgIn, predSeg, trueSeg)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%Copy background to image 
imgOut(:,:,1) = imgIn;  %R
imgOut(:,:,2) = imgIn;  %G
imgOut(:,:,3) = imgIn;  %B

predSkel = wormskel(predSeg);
trueSkel = wormskel(trueSeg);

predF = regionprops(predSeg);
trueF = regionprops(predSeg);

predCentroid = round([predF(:).Centroid]);
trueCentroid = round([trueF(:).Centroid]);

predPerim = bwperim(predSeg);
truePerim = bwperim(trueSeg);

%% Predicted is RED
imgRed(:,:,1) = predSkel | predPerim;

imgBlue(:,:,3) = trueSkel | truePerim;

[i1, i2] = find (imgRed(:,:,1) == 1);
[i3, i4] = find(imgBlue(:,:,3) == 1);


for i = 1:size(i3)
    imgOut(i3(i),i4(i),1) = 0;
    imgOut(i3(i),i4(i),2) = 0;
    imgOut(i3(i),i4(i),3) = max(max(imgIn));
end

%imgOut(trueCentroid(1), trueCentroid(2), 3) = max(max(imgIn));

for i = 1:size(i1)
    imgOut(i1(i),i2(i),1) = max(max(imgIn));
    imgOut(i1(i),i2(i),2) = 0;
    imgOut(i1(i),i2(i),3) = 0;
end

%imgOut(predCentroid(1), predCentroid(2), 3) = max(max(imgIn));

imgOut = double(imgOut);
imgOut = imgOut/max(max(max(imgOut)));


end

