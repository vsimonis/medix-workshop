videoDir = 'C:\Users\vsimonis\Documents\MATLAB\NematodesMedia\Hoky1\';
workingDir = 'C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj';

wormMovie = uint8(zeros(600,800,50));
list = dir(videoDir);
seqnum = 0;
size(list)
for i = 1:size(list,1)
   if list(i).isdir ~= 1
       t = strfind(list(i).name, '.tif');
        if ~isempty(t)
            seqnum = seqnum + 1; 
            videoFullPath = sprintf('%s%s',videoDir, list(i).name);
            [image,map] = imread(videoFullPath,1);
            bw = segWormHist(image);
            imwrite(bw, sprintf('%s', list(i).name));
            
            wormMovie(:,:,seqnum) = image;
        end
   end
end

