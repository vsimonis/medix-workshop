function [ imgOut] = eliminateBorder( imgIn, padding )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

[row, col] = size(imgIn);
x = padding;
y = padding;
w = col - 2*padding;
h = row - 2*padding;
imgOut = imcrop(imgIn, [x y w h]);

end

