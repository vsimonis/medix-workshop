%% Configuration 

MAIN_PATH = 'C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj\';
MEDIA_PATH = 'C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj\Media\';
VIDEO_PATH = 'C:\\Users\\vsimonis\\Downloads\\led_tests\\';
WRITE_PATH = 'C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj\Media\write\';
addpath(MAIN_PATH, MEDIA_PATH, VIDEO_PATH);

