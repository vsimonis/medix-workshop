function [ imgOut] = SegWormRon(imgIn)
    %SegWorm - Segments the worm and retruns a BW image

    try
        %Get the size of the frame
        [rowsInFrame, colsInFrame] = size(imgIn);
        %% Threshold and create BW image

        % Use Otsu's algorithm to threshold the image and convert to a logical
        % image
        level  = graythresh(imgIn);
        imgOut = im2bw(imgIn, level);


        % Take the complement to make the worm the foreground
        imgOut = imcomplement(imgOut);

        %Delete any break away pixels from the bwframe nd remove the structure 
        %from the structure array starting from the back of the array
        frameProps = regionprops(imgOut, 'PixelList');
        theSize =  size(frameProps, 1);
        if theSize > 1
            for i = theSize: -1 :2
                for j = 1:size(frameProps(i).PixelList,1)
                    %Reverse the pixellist coord to get the row and col

                    imgOut( frameProps(i).PixelList(j,2), frameProps(i).PixelList(j,1) ) = 0;
                end
                frameProps(i)=[];
            end
        end


        SE = strel('disk', 2, 0);
        imgOut = imclose(imgOut, SE);

        %Fill in holes in the foreground image
        imgOut = imfill(imgOut, 'holes');

    catch ME
        msgString = getReport(ME);
        fprintf(msgString);
        rethrow(ME);
    end
end

