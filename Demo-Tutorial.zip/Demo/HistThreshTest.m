close all; clear;

area = 2445 - 3*19;

I = getImage('hoky2-276');

I1 = threshOtsu(I);
S1 = segThresh(I1);
figure; imshow(I1);
figure; imshow(S1);

I4 = threshHist(I);
S4 = segThresh(I4);
figure; imshow(I4);
figure; imshow(S4);


I2 = threshAUHist(I, area);
S2 = segThresh(I2);
figure; imshow(I2);
figure; imshow(S2);


I3 = threshPHist(I, area);
;


figure; imshow(I1);
figure; imshow(I2);
figure; imshow(I3);
figure; imshow(I4);