%% MultiFrame Segmentation Test

Configuration;

%wormMovie = uint8(zeros(NROWS,NCOLS,NUMFRAMES));
list = dir(VIDEO_PATH);
segFunc = @segWormHist;

seqnum = 0;
size(list);
for i = 1:size(list,1)
   if list(i).isdir ~= 1
       t = strfind(list(i).name, '.tif');
        if ~isempty(t)
            seqnum = seqnum + 1; 
            videoFullPath = sprintf('%s%s',VIDEO_PATH, list(i).name);
            [image,map] = imread(videoFullPath,1);
            %wormMovie(:,:,seqnum) = image;
            segI = segFunc(image);
            imwrite(segI, sprintf('%sbw-%d.jpg', WRITE_PATH, seqnum - 1));
        end
   end
end
