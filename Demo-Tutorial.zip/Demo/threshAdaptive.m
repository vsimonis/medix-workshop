function [ imgOut ] = threshAdaptive( imgIn, n, thresh )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here


fun = @(block_struct) ...
        applyThresh(block_struct.data, thresh(block_struct.data));
    
imgOut = blockproc(imgIn, [n n], fun);
% Partition into nxn non-overlapping blocks


% Analyze histogram of each block, set threshold

% Form thresholding surface
end

