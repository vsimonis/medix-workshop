function [ imgOut ] = threshSmartHist( imgIn, avg )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

%% Gray level histogram

%http://www.mathworks.com/matlabcentral/
%answers/83437-how-do-i-find-the-maximum-and-minimum-of-a-histogram-in-matlab
imgOut = zeros(size(imgIn, 1), size(imgIn, 2));
%imgOut = imgIn;
% Maximum value in histogram is BG

imgIn = getImage('hoky2f1');

%tic;
avg = 4425+19;
[pixelCount grayLevel] = imhist(imgIn);
% indMaxBG = find( pixelCount == max(pixelCount));
% BGlevel = grayLevel(indMaxBG);

auh = 0;
glv = 255;
while (auh < avg)
   auh = auh + pixelCount(glv + 1);
   glv = glv - 1;
end

thresh = glv - 1
ind = find(imgIn > thresh);
imgOut(ind)= 1;


thresh = 84
ind = find(imgIn > thresh);
imgOut(ind)= 1;


toc;

tic;
a = reshape(imgIn, 1, size(imgIn,1)*size(imgIn,2));
a = sort(a);
p = 100 - avg/(size(imgIn,1)*size(imgIn,2))*100;
thresh = prctile(a,p)
toc;



ind = find(imgIn > thresh);
imgOut(ind)= 1;


% 
% %% Edge detection
% 
% %% Morphological closing
% imgOut = imcomplement(imgOut);
% 
% 
% SE = strel('disk', 3, 0);
% imgOut = imclose(imgOut,SE);
% imgOut = bwmorph(imgOut,'close',1);
% 
% %Fill in holes in the foreground image
% imgOut = imfill(imgOut, 'holes');
% 
% 
% 
% %% Keep largest connected component
% temp = imgOut;
% 
% imgOut = zeros(size(imgIn, 1), size(imgIn, 2));
% 
% CC = bwconncomp(temp, 4);
% numPix = cellfun(@numel,CC.PixelIdxList);
% [biggest, idx] = max(numPix);
% imgOut(CC.PixelIdxList{idx}) = 1;
% 
% 
% 
% 
% 
% %% Reference: 2012 -- 
% % "Locomotion Analysis identifies roles
% % of mechanosensory neurons in governming locomotion dynamics
% % of C. elegans"

end

