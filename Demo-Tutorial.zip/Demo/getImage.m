function [ I, map ] = getImage( imageType )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
dir = sprintf('%s%s',pwd,'\Media\TestImages\');

[I, map] = imread(sprintf('%s%s.tif', dir, imageType));

end

