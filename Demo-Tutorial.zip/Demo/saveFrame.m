function [ none ] = saveFrame( videoMatrix, frameNum, globalFrameNum, vidName )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
dir = 'C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj\Media\';
imwrite(videoMatrix(:,:, frameNum), colormap(gray(256)), sprintf('%s%s-%d.tif', dir, vidName, globalFrameNum));

end

