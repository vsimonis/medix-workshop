function [ imgOut ] = segHand( imgIn )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
R = imgIn(:,:,1);

imgOut = zeros(size(R,1), size(R,2));

ind = find(R == max(max(R)));
imgOut(ind)= 1;

end

