%% MainController
% 10/18/2013

global wormMovie;
global frameData;
global inum;

inum = 0;
close all;
Configuration; %Set session variables
MakeMovie; %Create movie from images

%% Process Frames (from RONALD NIEHAUS, processFrames.m)
nFrames = size(wormMovie(:,:,:),3);

%% Determine frames to process
firstFrame = 1;
lastFrame = 300;
segFunc = @segThresh;
threshFunc = @threshAUHist;

frameData = struct([]);

i = 0;
j = 0;

for iFrame = firstFrame:lastFrame
    i = i + 1;
    currentFrame = wormMovie(:,:,iFrame);
    
    %% Threshold
    if (i > 1 && i < 5)
        threshFrame = threshFunc(currentFrame, frameData(i-1).avgArea, frameData(i-1).sdArea);
    elseif i == 1
        threshFrame = threshHist(currentFrame);
    else
        threshFrame = threshFunc(currentFrame, frameData(4).avgArea, frameData(4).sdArea);
    end
    %% Get area
    if (i < 5)
        area = regionprops(imcomplement(threshFrame), 'Area');
    end
    
    %% Save info
    frameData(i).Original = iFrame - 1;
    frameData(i).SeqNum = iFrame;
    frameData(i).threshFrame = threshFrame;
    %frameData(i).segFrame = segFrame;
    
    if (i < 5)
        frameData(i).Area = area.Area;
        if(i == 1)
            frameData(i).cumArea = frameData(i).Area;
        else
            frameData(i).cumArea = frameData(i-1).cumArea + frameData(i).Area;
        end
        frameData(i).avgArea = frameData(i).cumArea / i;

        frameData(i).sseArea = abs(frameData(i).Area - frameData(i).avgArea)^2;
        if(i == 1)
            frameData(i).cumSSEArea = frameData(i).sseArea;
        else
            frameData(i).cumSSEArea = frameData(i-1).sseArea + frameData(i).sseArea;
        end

        frameData(i).sdArea = sqrt(frameData(i).cumSSEArea/i);
    end
    %% Segmentation
  
    frameData(i).segFrame = segFunc(frameData(i).threshFrame);
    
    inum = i;
end


