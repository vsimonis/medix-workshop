function [ thresh ] = getThreshHist( imgIn )
%% Gray level histogram

%http://www.mathworks.com/matlabcentral/
%answers/83437-how-do-i-find-the-maximum-and-minimum-of-a-histogram-in-matlab
imgOut = zeros(size(imgIn, 1), size(imgIn, 2));
%imgOut = imgIn;
% Maximum value in histogram is BG
[pixelCount grayLevel] = imhist(imgIn)
indMaxBG = find( pixelCount == max(pixelCount))
BGlevel = grayLevel(indMaxBG)
 



%% Nearest minimum below this maximum is threshold 
d1 = zeros(size(pixelCount));

for i = 2:size(pixelCount) - 1
    d1(i) = pixelCount(i+1) - pixelCount(i);
end

neighborhood = min(size(pixelCount - indMaxBG), indMaxBG);

i = 1;
while(d1(indMaxBG - i) > 0)
    posNearMinIndexL = indMaxBG - i
    i = i + 1;
end

thresh = grayLevel(posNearMinIndexL);

end

