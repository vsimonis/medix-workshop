function [ imgOut] = minmax( imgIn )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
minn = min(min(imgIn));
maxx = max(max(imgIn));

imgOut = round(double(imgIn - minn)/(maxx - minn)*255)

end

