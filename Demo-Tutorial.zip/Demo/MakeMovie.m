%%Make Movie
list = dir(VIDEO_PATH);

k = 1;
while list(k).isdir ~= 0
    k = k + 1;
end

sampleI = imread(list(k).name);
NROWS = size(sampleI, 1);
NCOLS = size(sampleI,2);
NUMFRAMES = size(list,1) - k; %estimation for efficiency, not necessary

wormMovie = uint8(zeros(NROWS,NCOLS,NUMFRAMES));

%segFunc = @segWormHist;

seqnum = 0;
size(list);
w = VideoWriter('video');
w.FrameRate = 6;
open(w);
for i = 1:size(list,1)
   if list(i).isdir ~= 1
       t = strfind(list(i).name, '.tif');
        if ~isempty(t)
            seqnum = seqnum + 1; 
            videoFullPath = sprintf('%s%s',VIDEO_PATH, list(i).name);
            image = imread(videoFullPath);
            wormMovie(:,:,seqnum) = image;
            writeVideo(w,image);
            %segI = segFunc(image);
            %imwrite(segI, sprintf('%sbw-%d.jpg', WRITE_PATH, seqnum - 1));
        end
   end
end
close(w);
clear NROWS NCOLS NUMFRAMES seqnum list i k ans map image t sampleI videoFullPath

%implay(wormMovie);