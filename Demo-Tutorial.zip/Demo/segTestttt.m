I = imread('ledtest-50.tif');
%I = imcrop(I, [173.5 203.5 722 672]);
t = getThreshHist(I);
J = applyThresh(I,t);
%J = morphOps(J,3);
imshow(J);

