% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nematodes (see VARARGIN)


% Create image data
handles.FirstFrame = getImage('hoky2f1');
handles.Curled = getImage('hoky2-158');
handles.Coiled = getImage('hoky2-160');
handles.Artifact = getImage('hoky2-296');
handles.IntersectArtifact = getImage('hoky2-276');
handles.Reg = getImage('reg');

handles.FirstFrameH = getImage('hoky2f1-hand');
handles.CurledH = getImage('hoky2-158-hand');
handles.CoiledH = getImage('hoky2-160-hand');
handles.ArtifactH = getImage('hoky2-296-hand');
handles.IntersectArtifactH = getImage('hoky2-276-hand');
handles.RegH = getImage('reg');

%Initialize parameters
handles.SizeSE = 3;
handles.SE = strel('disk', handles.SizeSE, 0);
handles.NB = 15;


%% Image Enhancement
handles.IE = @none;

%% Image Thresholding
handles.T = @(I)threshAUHist(I, 4223, 19);
handles.tval = @(I)getThreshAUHist(handles.IE(I), 4223, 19);
handles.thresh = @(I)getThreshAUHist(I);

%% Morphological Operations
% Static
handles.MD = @(I)imdilate(imcomplement(I), handles.SE);
handles.ME = @(I)imerode(imcomplement(I), handles.SE);
handles.MC = @(I)imerode(imdilate(imcomplement(I),handles.SE), handles.SE);
handles.MO = @(I)imdilate(imerode(imcomplement(I),handles.SE), handles.SE);

% Dynamic
handles.M = @(I, sizese)morphOps(I, sizese);
handles.getFeatures = @(I)regionprops(I);

%%%%%%%%%%%%%%%%%%
originals(:,:,1) = handles.FirstFrame;
originals(:,:,2) = handles.Curled;
originals(:,:,3) = handles.Coiled;
originals(:,:,4) = handles.Artifact;
originals(:,:,5)= handles.IntersectArtifact;

handseg(:,:,1) = segHand(handles.FirstFrameH);
handseg(:,:,2) = segHand(handles.CurledH);
handseg(:,:,3) = segHand(handles.CoiledH);
handseg(:,:,4) = segHand(handles.ArtifactH);
handseg(:,:,5) = segHand(handles.IntersectArtifactH);

valseg(:,:,1) = handles.M(handles.T(handles.IE(handles.FirstFrame)), handles.SizeSE);
valseg(:,:,2) = handles.M(handles.T(handles.IE(handles.Curled)), handles.SizeSE);
valseg(:,:,3) = handles.M(handles.T(handles.IE(handles.Coiled)), handles.SizeSE);
valseg(:,:,4) = handles.M(handles.T(handles.IE(handles.Artifact)), handles.SizeSE);
valseg(:,:,5) = handles.M(handles.T(handles.IE(handles.IntersectArtifact)), handles.SizeSE);


for i = 1:5
    handf(i) = handles.getFeatures(handseg(:,:,i));
    handarea(i) = [handf(i).Area];
end

for i = 1:5
    f(i) = handles.getFeatures(valseg(:,:,i));
    area(i) = [f(i).Area];
    centroid(i,1:2) = [f(i).Centroid];
end

for i = 1:5
    fn = sprintf('\\datasets\\%s-%s-%s-SEsize-%d-%d.jpg', ...
        func2str(handles.IE), ...
        func2str(handles.T), ...
        func2str(handles.M), ...
        handles.SizeSE, ...
        i);
    f = figure(i);
    imshow(overImg(...
        originals(:,:,i), ...
        wormskel(valseg(:,:,i)), ...
        bwperim(valseg(:,:,i))));
    hold on;
    plot(centroid(i,1),centroid(i,2),'b.','MarkerSize',15);
    hold off;
    saveas(figure(i),[pwd fn]);
end
