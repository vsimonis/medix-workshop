function [ imgOut ] = overImg( imgBG, imgOverRed, imgOverGreen )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%imgBG = double(imgBG);
%Turn imgOver to red
imgRed = zeros(size(imgOverRed,1), size(imgOverRed, 2), 3);
imgRed(:,:,1) = imgOverRed;
imgGreen(:,:,2) = imgOverGreen;



imgOut = zeros(size(imgBG,1), size(imgBG,2),3);

%Copy background to image 
imgOut(:,:,1) = imgBG;  %R
imgOut(:,:,2) = imgBG;  %G
imgOut(:,:,3) = imgBG;  %B

% imgOut(round(imgOverBlue(1)), round(imgOverBlue(2)),3) = max(max(imgBG));
% 
% imgOut(round(imgOverBlue(1)) + 1, round(imgOverBlue(2)),3) = max(max(imgBG));
% imgOut(round(imgOverBlue(1)) - 1, round(imgOverBlue(2)),3) = max(max(imgBG));
% imgOut(round(imgOverBlue(1)), round(imgOverBlue(2)) + 1 ,3) = max(max(imgBG));
% imgOut(round(imgOverBlue(1)), round(imgOverBlue(2)) - 1,3) = max(max(imgBG));

% 
% imgOut(round(imgOverBlue(1)) + 1, round(imgOverBlue(2)),3 + 1) = max(max(imgBG));
% imgOut(round(imgOverBlue(1)) - 1, round(imgOverBlue(2)),3 - 1) = max(max(imgBG));

[i1, i2] = find (imgRed(:,:,1) == 1);
[i3, i4] = find(imgGreen(:,:,2) == 1);

for i = 1:size(i1)
    imgOut(i1(i),i2(i),1) = max(max(imgBG));
    imgOut(i1(i),i2(i),2) = 0;
    imgOut(i1(i),i2(i),3) = 0;
end

for i = 1:size(i3)
    imgOut(i3(i),i4(i),1) = 0;
    imgOut(i3(i),i4(i),2) = max(max(imgBG));
    imgOut(i3(i),i4(i),3) = 0;
end

imgOut = double(imgOut);
imgOut = imgOut/max(max(max(imgOut)));
