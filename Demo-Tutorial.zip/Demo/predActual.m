clear
P = getImage('hoky2f1');
A = getImage('hoky2f1-hand');

Pt = threshHist(P);
Ps = morphOps(Pt,3);
As = segHand(A);


figure; imshow(Ps);
figure; imshow(As);

R = overImgResults(P,Ps,As);
imshow(R);
