function [ imgOut ] = gray2RGB( imgIn )

imgIn = double(imgIn);
a = 255;
b = 2*pi / 255;
c = pi / 5;


R = zeros(size(imgIn,1), size(imgIn,2));
G = zeros(size(imgIn,1), size(imgIn,2));
B = zeros(size(imgIn,1), size(imgIn,2));

for i = 1:size(imgIn,1)
    for j = 1: size(imgIn,2)
        R(i,j) = round(a * abs(sin(b*imgIn(i,j))));         % a*|sin(bx)|
        G(i,j) = round( a * abs(sin(b*imgIn(i,j) + c)));    % a*|sin(bx + c)|
        B(i,j) = round(a * abs(sin(b*imgIn(i,j) + 2*c)));   % a*|sin(bx+ 2c)|
    end
end

imgOut(:,:,1) = R;
imgOut(:,:,2) = G;
imgOut(:,:,3) = B;



end

