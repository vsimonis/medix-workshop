function [ imgOut ] = threshPHist( imgIn, area )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
a = reshape(imgIn, 1, size(imgIn,1)*size(imgIn,2));
a = sort(a);
p = area/(size(imgIn,1)*size(imgIn,2))*100;
thresh = prctile(a,p);
imgOut = applyThresh(imgIn, thresh);
end

