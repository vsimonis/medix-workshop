function [ imgOut ] = none( imgIn )
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
imgOut = imgIn;

end

