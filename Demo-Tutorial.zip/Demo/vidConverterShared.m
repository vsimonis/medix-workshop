%% Get Some Video Frames

%% Specify video to read in
fName = 'tph-1nofood1-Tue_12_Aug_2014-171059.avi';
VIDEO_PATH = 'C:\Users\vsimonis\Documents\MATLAB\Data\tph-1_nofood1\';


%% Codec issues work around to read video into matlab
% % due to Codec issues, do mmread in (available from Mathworks)
% tempVidIn = mmread(sprintf('%s%s', VIDEO_PATH,fName));
% % write temp video out
% tempVidOut = VideoWriter(sprintf('%s%s%s',VIDEO_PATH, 'Out', fName));
% % Open stream to actually write the video to disk 
% open(tempVidOut);
% % Write video to disk
% tempVidOut.writeVideo(tempVidIn.frames);
% % Close stream 
% close(tempVidOut);
% clear tempVidOut

%% Read in File and get image frames

% without Codec override
wormVid = VideoReader(sprintf('%s%s', VIDEO_PATH, fName));
% with Codec override
%wormVid = VideoReader(sprintf('%s%s', 'Out', fName));

props = get(wormVid);
nFrames = props.NumberOfFrames;
interval = 1000;
first = 1;
last = first + interval;
saveRate = 10;
count = 1;

gFrame = 1;

while (last < nFrames - 1)
    
    subsetFrames = read(wormVid, [first last]);
    %grayFrames = zeros(props.Height, props.Width ,interval);
    
    for i = 1:interval
        %grayFrames(:,:,i) = rgb2gray(subsetFrames(:,:,:,i));
        gFrame = gFrame + 1;
        if (mod(gFrame, saveRate) == 0)
           %saveFrame(grayFrames, i, gFrame, 'RHO-1');
           %imwrite(grayFrames(:,:,i), sprintf('%s-frame-%d.tif', fName, i));
           imwrite(subsetFrames(:,:,1,i), sprintf('%s-frame-%d.tif', fName, i));

        end
    end
 
    first = gFrame + 1;
    last = first + interval;
  
    if(last > nFrames)
        last = nFrames - 1;
        interval = last - first;
    end
    
end



