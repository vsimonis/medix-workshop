foldir = 'C:\Users\vsimonis\Documents\MATLAB\PreviousWork\Intro to Img Processing\FinalProj'
for file = dir(foldir)'
    if ~isempty(strfind(file.name, '.tif'))
        I = imread(sprintf('%s\\%s', foldir, file.name));
        t = graythresh(I);
        BW = im2bw(I, t);
        imshow(BW);
        imwrite(BW, sprintf('%s-thresh.tif', file.name))
        
    end
end