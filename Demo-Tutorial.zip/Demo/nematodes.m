function varargout = nematodes(varargin)
% NEMATODES MATLAB code for nematodes.fig
%      NEMATODES, by itself, creates a new NEMATODES or raises the existing
%      singleton*.
%
%      H = NEMATODES returns the handle to a new NEMATODES or the handle to
%      the existing singleton*.
%
%      NEMATODES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NEMATODES.M with the given input arguments.
%
%      NEMATODES('Property','Value',...) creates a new NEMATODES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before nematodes_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to nematodes_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help nematodes

% Last Modified by GUIDE v2.5 23-Nov-2013 12:59:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @nematodes_OpeningFcn, ...
                   'gui_OutputFcn',  @nematodes_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before nematodes is made visible.
function nematodes_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nematodes (see VARARGIN)
%cwd = 
%cd('C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj\');
addpath(pwd);
% Create image data
handles.FirstFrame = getImage('hoky2f1');
handles.Curled = getImage('hoky2-158');
handles.Coiled = getImage('hoky2-160');
handles.Artifact = getImage('hoky2-296');
handles.IntersectArtifact = getImage('hoky2-276');
handles.Reg = getImage('reg');

handles.FirstFrameH = getImage('hoky2f1-hand');
handles.CurledH = getImage('hoky2-158-hand');
handles.CoiledH = getImage('hoky2-160-hand');
handles.ArtifactH = getImage('hoky2-296-hand');
handles.IntersectArtifactH = getImage('hoky2-276-hand');
handles.RegH = getImage('reg');

%Initialize parameters
handles.SizeSE = 3;
handles.SE = strel('disk', handles.SizeSE, 0);
handles.NB = 15;

% Initialize functions
handles.frame = handles.FirstFrame;
handles.comparison = handles.FirstFrameH;
handles.segcomp = segHand(handles.comparison);

%% Image Enhancement
handles.IE = @none;

%% Image Thresholding
handles.T = @(I)none(I);
handles.tval = 0;

%% Morphological Operations
% Static
handles.MD = @(I)imdilate(imcomplement(I), handles.SE);
handles.ME = @(I)imerode(imcomplement(I), handles.SE);
handles.MC = @(I)imerode(imdilate(imcomplement(I),handles.SE), handles.SE);
handles.MO = @(I)imdilate(imerode(imcomplement(I),handles.SE), handles.SE);

% Dynamic
handles.M = @(I, sizese)morphOps(I, sizese);
handles.getFeatures = @(I)regionprops(I);
%% Feature Calculation
% try
    handles.Features = handles.getFeatures(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE));
    handles.Centroid = [handles.Features(:).Centroid];
    handles.Area = [handles.Features(:).Area];
    handles.BoundingBox = [handles.Features(:).BoundingBox];

% catch exception
%     handles.Centroid = 'error';
%     handles.Area = 'error';
%     handles.BoundingBox = 'error';
% end

handles.compFeatures = handles.getFeatures(handles.segcomp);
handles.compCentroid = [handles.compFeatures(:).Centroid];
handles.compArea = [handles.compFeatures(:).Area];
handles.compBoundingBox = [handles.compFeatures(:).BoundingBox];

set(handles.cArea, 'String', num2str(handles.compArea));
set(handles.sArea, 'String', num2str(handles.Area));
set(handles.pcent, 'String', num2str((handles.Area / handles.compArea)*100));

% Initialize displayed images
imshow(handles.frame, 'Parent', handles.Original);
imshow(handles.IE(handles.frame), 'Parent', handles.ImageEnhancement);
imshow(handles.T(handles.IE(handles.frame)), 'Parent', handles.Threshold);
imshow(handles.MD(handles.T(handles.IE(handles.frame))), 'Parent', handles.Dilation);
imshow(handles.ME(handles.T(handles.IE(handles.frame))), 'Parent', handles.Erosion);
imshow(handles.MC(handles.T(handles.IE(handles.frame))), 'Parent', handles.Closing);
imshow(handles.MO(handles.T(handles.IE(handles.frame))), 'Parent', handles.Opening);
imshow(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE), 'Parent', handles.Morphology);

hideResultsAxes(hObject, eventdata, handles)

% Display information
set(handles.nBlock, 'String', handles.NB);
set(handles.nSE, 'String', handles.SizeSE);
set(handles.tShow, 'String', handles.tval);
set(handles.tNone,'Value',1);
set(handles.IENone,'Value',1);
set(handles.normal,'Value',1);


linkaxes([handles.ImageEnhancement handles.Original handles.Threshold ...
    handles.Erosion handles.Dilation handles.Closing ...
    handles.Opening handles.Morphology ...
    handles.ResultsCompare handles.ResultsThis], 'xy');

% Choose default command line output for nematodes
handles.output = hObject;
%bReset_Callback(hObject, eventdata, handles);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes nematodes wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = nematodes_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in chooseImage.
function chooseImage_Callback(hObject, eventdata, handles)
% hObject    handle to chooseImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns chooseImage contents as cell array
%        contents{get(hObject,'Value')} returns selected item from chooseImage
val = get(hObject, 'Value');
str = get(hObject, 'String');
switch str{val}
    case 'First Frame'
        handles.frame = handles.FirstFrame;
        handles.comparison = handles.FirstFrameH;
    case 'Curled'
        handles.frame = handles.Curled;
        handles.comparison = handles.CurledH;
    case 'Coiled'
        handles.frame = handles.Coiled;
        handles.comparison = handles.CoiledH;
    case 'Artifact'
        handles.frame = handles.Artifact;
        handles.comparison = handles.ArtifactH;
    case 'Intersect Artifact'
        handles.frame = handles.IntersectArtifact;
        handles.comparison = handles.IntersectArtifactH;
    case 'Reg'
        handles.frame = handles.Reg;
        handles.comparison = handles.Reg;
end

handles.segcomp = segHand(handles.comparison);

guidata(hObject, handles);
chooseImageUpdate(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function chooseImage_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chooseImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function Original_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Original (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate Original


% --- Executes when selected object is changed in IEPanel.
function IEPanel_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in IEPanel 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

switch get(eventdata.NewValue, 'Tag')
    case 'HE'
        handles.IE = @histeq;
    case 'CS'
        handles.IE = @(I)imadjust(I, [0.1,0.25], [0,1],1);

    case 'IENone'
        handles.IE = @none;  
end

oldsel = get(handles.TPanel, 'SelectedObject');
newsel = get(handles.TPanel, 'SelectedObject');
fakeevent = struct('EventName', 'SelectionChanged', 'OldValue', oldsel,'NewValue', oldsel);

TPanel_SelectionChangeFcn(handles.TPanel, fakeevent, handles);


guidata(hObject, handles);
update_Callback(hObject, eventdata, handles);


% --- Executes when selected object is changed in TPanel.
function TPanel_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in TPanel 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
switch get(eventdata.NewValue, 'Tag')
    case 'tMean'
        handles.T = @(I)applyThresh(I, mean(mean(I)));
        handles.tval = mean(mean(handles.IE(handles.frame)));
        handles.thresh = @(I)mean(mean(I));
    case 'tOtsu'
        handles.T = @(I)threshOtsu(I);
        handles.tval = graythresh(handles.IE(handles.frame))*255;
        handles.thresh = @(I)graythresh(I);
    case 'tHist'
        handles.T = @(I)threshHist(I); 
        handles.tval = getThreshHist(handles.IE(handles.frame));
        handles.thresh = @(I)getThreshHist(I);
    case 'tAUHist'
        handles.T = @(I)threshAUHist(I, 4223, 19);
        handles.tval = getThreshAUHist(handles.IE(handles.frame), 4223, 19);
        handles.thresh = @(I)getThreshAUHist(I);
    case 'tNone'
        handles.T = @none;
        handles.tval = 'none';
        handles.thresh = @none;
      
end


% oldsel = get(handles.IEPanel, 'SelectedObject');
% newsel = get(handles.IEPanel, 'SelectedObject');
% fakeevent = struct('EventName', 'SelectionChanged', 'OldValue', oldsel,'NewValue', oldsel);
% IEPanel_SelectionChangeFcn(handles.IEPanel, fakeevent, handles);


set(handles.tShow, 'String', handles.tval);
guidata(hObject, handles);
update_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function IEPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IEPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on scroll wheel click while the figure is in focus.
function figure1_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in tAdaptive.
function tAdaptive_Callback(hObject, eventdata, handles)
% hObject    handle to tAdaptive (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.T = @(I)threshAdaptive(I, handles.NB, handles.thresh); 
guidata(hObject, handles);
update_Callback(hObject, eventdata, handles);


function nBlock_Callback(hObject, eventdata, handles)
% hObject    handle to nBlock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nBlock as text
%        str2double(get(hObject,'String')) returns contents of nBlock as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end
handles.NB = user_entry;
guidata(hObject, handles);

update_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function nBlock_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nBlock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nSE_Callback(hObject, eventdata, handles)
% hObject    handle to nSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nSE as text
%        str2double(get(hObject,'String')) returns contents of nSE as a double
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry)
  errordlg('You must enter a numeric value','Bad Input','modal')
  uicontrol(hObject)
	return
end
handles.SizeSE = user_entry;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function nSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in bSE.
function bSE_Callback(hObject, eventdata, handles)
% hObject    handle to bSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.SE = strel('disk', handles.SizeSE, 0);
handles.MD = @(I)imdilate(imcomplement(I), handles.SE);
handles.ME = @(I)imerode(imcomplement(I),handles.SE);
handles.MC = @(I)imerode(handles.MD(I), handles.SE);
handles.MO = @(I)imdilate(handles.ME(I), handles.SE);
guidata(hObject, handles);
update_Callback(hObject, eventdata, handles);



function tShow_Callback(hObject, eventdata, handles)
% hObject    handle to tShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tShow as text
%        str2double(get(hObject,'String')) returns contents of tShow as a double


% --- Executes during object creation, after setting all properties.
function tShow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sArea_Callback(hObject, eventdata, handles)
% hObject    handle to sArea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sArea as text
%        str2double(get(hObject,'String')) returns contents of sArea as a double


% --- Executes during object creation, after setting all properties.
function sArea_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sArea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function Morphology_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Morphology (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate Morphology



function cArea_Callback(hObject, eventdata, handles)
% hObject    handle to cArea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cArea as text
%        str2double(get(hObject,'String')) returns contents of cArea as a double


% --- Executes during object creation, after setting all properties.
function cArea_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cArea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in bReset.
function bReset_Callback(hObject, eventdata, handles)
% hObject    handle to bReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --- Executes on button press in sResults.
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nematodes (see VARARGIN)

%Initialize parameters
handles.SizeSE = 3;
handles.SE = strel('disk', handles.SizeSE, 0);
handles.NB = 15;

%% Image Enhancement
handles.IE = @none;

%% Image Thresholding
handles.T = @(I)none(I);
handles.tval = 0;

%% Morphological Operations
% Static
handles.MD = @(I)imdilate(imcomplement(I), handles.SE);
handles.ME = @(I)imerode(imcomplement(I), handles.SE);
handles.MC = @(I)imerode(imdilate(imcomplement(I),handles.SE), handles.SE);
handles.MO = @(I)imdilate(imerode(imcomplement(I),handles.SE), handles.SE);

% Dynamic
handles.M = @(I, se)morphOps(I, se);
handles.getFeatures = @(I)regionprops(I);
%% Feature Calculation
% try
    handles.Features = handles.getFeatures(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE));
    handles.Centroid = [handles.Features(:).Centroid];
    handles.Area = [handles.Features(:).Area];
    handles.BoundingBox = [handles.Features(:).BoundingBox];

% catch exception
%     handles.Centroid = 'error';
%     handles.Area = 'error';
%     handles.BoundingBox = 'error';
% end

handles.compFeatures = handles.getFeatures(handles.segcomp);
handles.compCentroid = [handles.compFeatures(:).Centroid];
handles.compArea = [handles.compFeatures(:).Area];
handles.compBoundingBox = [handles.compFeatures(:).BoundingBox];

set(handles.cArea, 'String', num2str(handles.compArea));
set(handles.sArea, 'String', num2str(handles.Area));
set(handles.pcent, 'String', num2str((handles.Area / handles.compArea)*100));

% Initialize displayed images
imshow(handles.frame, 'Parent', handles.Original);
imshow(handles.IE(handles.frame), 'Parent', handles.ImageEnhancement);
imshow(handles.T(handles.IE(handles.frame)), 'Parent', handles.Threshold);
imshow(handles.MD(handles.T(handles.IE(handles.frame))), 'Parent', handles.Dilation);
imshow(handles.ME(handles.T(handles.IE(handles.frame))), 'Parent', handles.Erosion);
imshow(handles.MC(handles.T(handles.IE(handles.frame))), 'Parent', handles.Closing);
imshow(handles.MO(handles.T(handles.IE(handles.frame))), 'Parent', handles.Opening);
imshow(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE), 'Parent', handles.Morphology);

hideResultsAxes(hObject, eventdata, handles)

% Display information
set(handles.nBlock, 'String', handles.NB);
set(handles.nSE, 'String', handles.SizeSE);
set(handles.tShow, 'String', handles.tval);
set(handles.tNone,'Value',1);
set(handles.IENone,'Value',1);
set(handles.normal,'Value',1);
guidata(hObject, handles);


function sResults_Callback(hObject, eventdata, handles)
% hObject    handle to sResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
showResultsAxes(hObject, eventdata, handles);
xlims = get(handles.Original, 'Xlim');
ylims = get(handles.Original, 'Ylim');
imshow(overImg(handles.frame, ...
    wormskel(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE)), ...
    bwperim(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE))),...
    'Parent', handles.ResultsThis);
hold on;
plot(handles.Centroid(1),handles.Centroid(2),'b.','MarkerSize',15, 'Parent', handles.ResultsThis);

imshow(overImgResults(handles.frame, ...
    handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE), handles.segcomp), ...
    'Parent', handles.ResultsCompare);
set(handles.Original, 'Xlim', xlims, 'Ylim', ylims);


% --- Executes when selected object is changed in MPanel.
function MPanel_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in MPanel 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
switch get(eventdata.NewValue, 'Tag')
    case 'normal'
        handles.M = @(I, se)morphOps(I, se);
    case 'medium'
        handles.M = @(I, se)morphOpsMedium(I, se);
end

guidata(hObject, handles);
update_Callback(hObject, eventdata, handles);

function chooseImageUpdate(hObject, eventdata, handles)

imshow(handles.frame, 'Parent', handles.Original);
imshow(handles.IE(handles.frame), 'Parent', handles.ImageEnhancement);
imshow(handles.T(handles.IE(handles.frame)), 'Parent', handles.Threshold);
imshow(handles.MD(handles.T(handles.IE(handles.frame))), 'Parent', handles.Dilation);
imshow(handles.ME(handles.T(handles.IE(handles.frame))), 'Parent', handles.Erosion);
imshow(handles.MC(handles.T(handles.IE(handles.frame))), 'Parent', handles.Closing);
imshow(handles.MO(handles.T(handles.IE(handles.frame))), 'Parent', handles.Opening);
imshow(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE), 'Parent', handles.Morphology);

% try
    handles.Features = handles.getFeatures(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE));
    handles.Centroid = [handles.Features(:).Centroid];
    handles.Area = [handles.Features(:).Area];
    handles.BoundingBox = [handles.Features(:).BoundingBox];
% 
% catch exception
%     handles.Centroid = 'error';
%     handles.Area = 'error';
%     handles.BoundingBox = 'error';
% end

handles.compFeatures = handles.getFeatures(handles.segcomp);
handles.compCentroid = [handles.compFeatures(:).Centroid];
handles.compArea = [handles.compFeatures(:).Area];
handles.compBoundingBox = [handles.compFeatures(:).BoundingBox];

hideResultsAxes(hObject, eventdata, handles)

set(handles.sArea, 'String', num2str(handles.Area));
set(handles.cArea, 'String', num2str(handles.compArea));
set(handles.pcent, 'String', num2str((handles.Area / handles.compArea)*100));
set(handles.pvalue, 'String', 'none');
guidata(hObject, handles);

% --- Executes on button press in update.
function update_Callback(hObject, eventdata, handles)
% hObject    handle to update (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

hideResultsAxes(hObject, eventdata, handles)

xlims = get(handles.Original, 'Xlim');
ylims = get(handles.Original, 'Ylim');

imshow(handles.frame, 'Parent', handles.Original);
imshow(handles.IE(handles.frame), 'Parent', handles.ImageEnhancement);
imshow(handles.T(handles.IE(handles.frame)), 'Parent', handles.Threshold);
imshow(handles.MD(handles.T(handles.IE(handles.frame))), 'Parent', handles.Dilation);
imshow(handles.ME(handles.T(handles.IE(handles.frame))), 'Parent', handles.Erosion);
imshow(handles.MC(handles.T(handles.IE(handles.frame))), 'Parent', handles.Closing);
imshow(handles.MO(handles.T(handles.IE(handles.frame))), 'Parent', handles.Opening);
imshow(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE), 'Parent', handles.Morphology);

set(handles.Original, 'Xlim', xlims, 'Ylim', ylims);

try
    handles.Features = handles.getFeatures(handles.M(handles.T(handles.IE(handles.frame)), handles.SizeSE));
    handles.Centroid = [handles.Features(:).Centroid];
    handles.Area = [handles.Features(:).Area];
    handles.BoundingBox = [handles.Features(:).BoundingBox];

catch exception
    handles.Centroid = 'error';
    handles.Area = 'error';
    handles.BoundingBox = 'error';
end

handles.compFeatures = handles.getFeatures(handles.segcomp);
handles.compCentroid = [handles.compFeatures(:).Centroid];
handles.compArea = [handles.compFeatures(:).Area];
handles.compBoundingBox = [handles.compFeatures(:).BoundingBox];

set(handles.pvalue, 'String', 'none');
set(handles.sArea, 'String', num2str(handles.Area));
set(handles.cArea, 'String', num2str(handles.compArea));
set(handles.pcent, 'String', num2str((handles.Area / handles.compArea)*100));
guidata(hObject, handles);

function showResultsAxes(hObject, eventdata, handles)
set(handles.ResultsCompare,'Visible','on');
set(handles.ResultsThis,'Visible','on');
set(handles.texthide1, 'Visible', 'on');
set(handles.texthide2, 'Visible', 'on');
set(handles.texthide3, 'Visible', 'on');
set(handles.texthide4, 'Visible', 'on');
set(handles.texthide5, 'Visible', 'on');
set(handles.texthide6, 'Visible', 'on');
set(handles.ttest, 'Visible', 'on');
set(handles.text20, 'Visible', 'on');
set(handles.pvalue, 'Visible', 'on');
guidata(hObject, handles);

function hideResultsAxes(hObject, eventdata, handles)

set(handles.ResultsCompare,'Visible','off');
set(handles.ResultsThis,'Visible','off');

one = get(handles.ResultsCompare, 'Children');
set(one, 'Visible', 'off');
two  = get(handles.ResultsThis, 'Children');
set(two, 'Visible', 'off');

set(handles.texthide1, 'Visible', 'off');
set(handles.texthide2, 'Visible', 'off');
set(handles.texthide3, 'Visible', 'off');
set(handles.texthide4, 'Visible', 'off');
set(handles.texthide5, 'Visible', 'off');
set(handles.ttest, 'Visible', 'off');
set(handles.text20, 'Visible', 'off');
set(handles.pvalue, 'Visible', 'off');
set(handles.texthide6, 'Visible', 'off');
guidata(hObject, handles);


% --- Executes on button press in ttest.
function ttest_Callback(hObject, eventdata, handles)
% hObject    handle to ttest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handseg(:,:,1) = segHand(handles.FirstFrameH);
handseg(:,:,2) = segHand(handles.CurledH);
handseg(:,:,3) = segHand(handles.CoiledH);
handseg(:,:,4) = segHand(handles.ArtifactH);
handseg(:,:,5) = segHand(handles.IntersectArtifactH);

valseg(:,:,1) = handles.M(handles.T(handles.IE(handles.FirstFrame)), handles.SizeSE);
valseg(:,:,2) = handles.M(handles.T(handles.IE(handles.Curled)), handles.SizeSE);
valseg(:,:,3) = handles.M(handles.T(handles.IE(handles.Coiled)), handles.SizeSE);
valseg(:,:,4) = handles.M(handles.T(handles.IE(handles.Artifact)), handles.SizeSE);
valseg(:,:,5) = handles.M(handles.T(handles.IE(handles.IntersectArtifact)), handles.SizeSE);


for i = 1:5
    handf(i) = handles.getFeatures(handseg(:,:,i));
    handarea(i) = [handf(i).Area];
end

for i = 1:5
    f(i) = handles.getFeatures(valseg(:,:,i));
    area(i) = [f(i).Area];
end

[h,p] = ttest(handarea, area);

set(handles.pvalue, 'String', num2str(p));
guidata(hObject, handles);



function pvalue_Callback(hObject, eventdata, handles)
% hObject    handle to pvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pvalue as text
%        str2double(get(hObject,'String')) returns contents of pvalue as a double


% --- Executes during object creation, after setting all properties.
function pvalue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pcent_Callback(hObject, eventdata, handles)
% hObject    handle to pcent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pcent as text
%        str2double(get(hObject,'String')) returns contents of pcent as a double


% --- Executes during object creation, after setting all properties.
function pcent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pcent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in makeset.
function makeset_Callback(hObject, eventdata, handles)
% hObject    handle to makeset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

originals(:,:,1) = handles.FirstFrame;
originals(:,:,2) = handles.Curled;
originals(:,:,3) = handles.Coiled;
originals(:,:,4) = handles.Artifact;
originals(:,:,5)= handles.IntersectArtifact;

handseg(:,:,1) = segHand(handles.FirstFrameH);
handseg(:,:,2) = segHand(handles.CurledH);
handseg(:,:,3) = segHand(handles.CoiledH);
handseg(:,:,4) = segHand(handles.ArtifactH);
handseg(:,:,5) = segHand(handles.IntersectArtifactH);

valseg(:,:,1) = handles.M(handles.T(handles.IE(handles.FirstFrame)), handles.SizeSE);
valseg(:,:,2) = handles.M(handles.T(handles.IE(handles.Curled)), handles.SizeSE);
valseg(:,:,3) = handles.M(handles.T(handles.IE(handles.Coiled)), handles.SizeSE);
valseg(:,:,4) = handles.M(handles.T(handles.IE(handles.Artifact)), handles.SizeSE);
valseg(:,:,5) = handles.M(handles.T(handles.IE(handles.IntersectArtifact)), handles.SizeSE);


for i = 1:5
    handf(i) = handles.getFeatures(handseg(:,:,i));
    handarea(i) = [handf(i).Area];
end

for i = 1:5
    f(i) = handles.getFeatures(valseg(:,:,i));
    area(i) = [f(i).Area];
    centroid(i,1:2) = [f(i).Centroid];
    bb{i} = [f(i).BoundingBox];
end


cd('datasets');
mkdir(func2str(handles.IE)); cd(func2str(handles.IE));
mkdir(func2str(handles.T)); cd(func2str(handles.T));
mkdir(func2str(handles.M));cd(func2str(handles.M));
mkdir(sprintf('%d',handles.SizeSE));cd(sprintf('%d',handles.SizeSE));


%%%%%%%% Write areas
[h,p] = ttest(handarea, area);
p = [p NaN NaN NaN NaN];
headers = {'Area'; 'Handarea'; 'percentOfHA'; 'ttest'}.';
data = [area ; handarea; (area./handarea)*100; p].';
data = num2cell(data);
output = vertcat(headers, data);
fname = 'A.csv';
xlswrite(fname, output);

    
%%%%%%%% Write images
for i = 1:5
    fn = sprintf('%d.jpg', i);
    fig = figure(i);
    I = overImg(...
        originals(:,:,i), ...
        wormskel(valseg(:,:,i)), ...
        bwperim(valseg(:,:,i)));
    imshow(I);
    hold on;
    plot(centroid(i,1),centroid(i,2),'b.','MarkerSize',15);
    hold off;
    saveas(fig,fn);
    
    fn2 = sprintf('%d-BB.jpg',i);
    fr = getframe;
    J = fr.cdata;
    K = imcrop(J, bb{i});
    imwrite(K, fn2);
    
    fn1 = sprintf('%d-seg.jpg',i);
    fig = figure(i);
    I = overImg(...
        valseg(:,:,i), ...
        wormskel(valseg(:,:,i)), ...
        bwperim(valseg(:,:,i)));
    imshow(I);
    hold on;
    plot(centroid(i,1),centroid(i,2),'b.','MarkerSize',15);
    hold off;
    saveas(fig,fn1);
    
    fn4 = sprintf('%d-BB-seg.jpg', i);
    fr = getframe;
    J = fr.cdata;
    K = imcrop(J, bb{i});
    imwrite(K, fn4);
    close;
    
end
%cd('C:\Users\vsimonis\Documents\MATLAB\Intro to Img Processing\FinalProj\');
cd(pwd)