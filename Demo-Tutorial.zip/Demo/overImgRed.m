function [ imgOut ] = overImgRed( imgBG, imgOver )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%imgBG = double(imgBG);
%Turn imgOver to red
imgRed = zeros(size(imgOver,1), size(imgOver, 2), 3);
imgRed(:,:,1) = imgOver;

imgOut = zeros(size(imgBG,1), size(imgBG,2),3);

%Copy background to image 
imgOut(:,:,1) = imgBG;  %R
imgOut(:,:,2) = imgBG;  %G
imgOut(:,:,3) = imgBG;  %B



[i1, i2] = find (imgRed(:,:,1) == 1);

for i = 1:size(i1)
    imgOut(i1(i),i2(i),1) = max(max(imgBG));
    imgOut(i1(i),i2(i),2) = 0;
    imgOut(i1(i),i2(i),3) = 0;
end

imgOut = double(imgOut);
imgOut = imgOut/max(max(max(imgOut)));
