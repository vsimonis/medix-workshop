function [ imgOut ] = segThresh( imgIn )
%UNTITLED5 Summary of this function goes here
%  Detailed explanation goes here

global inum;
%% Take the negative
imgOut = ~imgIn;


%% Keep largest connected component
temp = imgOut;

imgOut = zeros(size(imgIn, 1), size(imgIn, 2));

CC = bwconncomp(temp, 4);
numPix = cellfun(@numel,CC.PixelIdxList);
[biggest, idx] = max(numPix);
imgOut(CC.PixelIdxList{idx}) = 1;

%% Morphological closing
SE = strel('disk', 3, 0);
imgOut = imclose(imgOut,SE);
imgOut = bwmorph(imgOut,'close',1);
%imgOut = ~imgOut;
imgOut = imfill(imgOut, 'holes');
% figure;imshow(imgOut);

imwrite(imgOut, sprintf('bSEGAUHIST-%d.jpeg', inum));


end

