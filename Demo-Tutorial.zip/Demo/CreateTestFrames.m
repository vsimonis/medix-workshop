%% Get Some Video Frames

%% Specify video to read in

fName = 'led_move1.avi';
interval = 1;


% Codec issues work around to read video into matlab
%due to Codec issues, do mmread in (available from Mathworks)
tempVidIn = mmread(sprintf('%s%s', VIDEO_PATH,fName));
%write temp video out
tempVidOut = VideoWriter(sprintf('%s%s%s',VIDEO_PATH, 'Out', fName));
%Open stream to actually write the video to disk 
open(tempVidOut);
%Write video to disk
tempVidOut.writeVideo(tempVidIn.frames);
%Close stream 
close(tempVidOut);
%clear tempVidOut

%% Read in File and get image frames
wormVid = VideoReader(sprintf('%s%s%s', VIDEO_PATH,'Out', fName));
%wormVid = VideoReader(sprintf('%s', fName));
props = get(wormVid);
nFrames = props.NumberOfFrames;
first = 1;
last = first + interval;

count = 1;

gFrame = 1;

while (last < nFrames - 1)
    
    subsetFrames = read(wormVid, [first last]);
    grayFrames = zeros(props.Height, props.Width ,interval);
    
    for i = 1:interval
        grayFrames(:,:,i) = rgb2gray(subsetFrames(:,:,:,i));
        %imshow(grayFrames(grayFrames(:,:,i)))
        gFrame = gFrame + 1;
        if (mod(gFrame, 1) == 0)
           saveFrame(grayFrames, i, gFrame, 'ledtest');
        end
    end
    gFrame;
    first = gFrame + 1
    last = first + interval
    interval;
    if(last > nFrames)
        last = nFrames - 1;
        interval = last - first;
    end
    
end

    
%     
%     
%     
%     if count == 1
%         subsetFrames = read(wormVid, [first last]);
%         grayFrames = zeros(props.Height, props.Width ,interval);
%         for current = first:last
%         grayFrames(:,:,current) = rgb2gray(subsetFrames(:,:,:,current));
%             if mod(current, 10) == 0
%                 saveFrame(grayFrames, current, current, 'RHO-1');
%             end
%         end
% 
%         first = last + 1
%         last = last + interval
%         if(last > nFrames)
%             last = nFrames;
%         end
%     end
%     
%     if count > 1 
%         subsetFrames = read(wormVid, [first last]);
%         grayFrames = zeros(props.Height, props.Width ,interval);
%         for current = first:last
%         grayFrames(:,:,last - current + 1) = rgb2gray(subsetFrames(:,:,:,last - current + 1));
%             if mod(current, 10) == 0
%                 saveFrame(grayFrames, last - current + 1, current, 'RHO-1');
%             end
%         end
% 
%         first = last + 1
%         last = last + interval
%         if(last > nFrames)
%             last = nFrames;
%         end
%     end
%     
%     count = count + 1;
% end


%{
for c = 1:nFrames
    
      subsetFrames = read(wormVid, [1 nFrames]);
    
end


subsetFrames = read(wormVid, [1 nFrames]);
%% Get frame data in 4-D struct and convert to grayscale
% I assume the object will have the video stored in a 4-D matrix with row, col, intensity, frame number).

grayFrames2 = zeros(size(subsetFrames, 1), size(subsetFrames, 2),nFrames);
for i = 1:nFrames
    grayFrames2(:,:,i) = rgb2gray(subsetFrames(:,:,:,i));
end

clear i;

for i = 1:nFrames
    if mod(i,10) == 0
        saveFrame(grayFrames2,i,'RHO1');
    end
end
%}

