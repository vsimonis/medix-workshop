%% Segmentation Tests
clear; close all;

%% Setup environment
Configuration;
% segFunc = @segWormRon;
% segFunc = @segWormHist;
segFunc = @segWormOtsu;

[imgIn, map] = getImage('hoky2f1');

imgOut = segFunc(imgIn);
figure; imshow(imgOut, map);
imwrite(imgOut,'out.tif');


%[imgIn, map] = getImage('reg');
% figure;
% imshow(imgIn);

I296 = getImage('hoky2-296');
I276 = getImage('hoky2-276');
I158 = getImage('hoky2-158');
I160 = getImage('hoky2-160');
imhist(I296);
imhist(I276);
imhist(I158);