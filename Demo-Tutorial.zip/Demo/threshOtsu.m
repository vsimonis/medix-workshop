function [ imgOut ] = threshOtsu( imgIn )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
    level  = graythresh(imgIn);
    imgOut = im2bw(imgIn, level);

end

